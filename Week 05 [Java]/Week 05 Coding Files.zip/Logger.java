package codingAssignment;

public interface Logger {

	public void log(String log);
	public void error(String error);
	
}
