"# week3Assignment" 
"Learning Arrays and Methods" 
